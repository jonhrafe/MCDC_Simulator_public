Free Diffusion
